import { Personnel, Region, Assignment } from '../types';

interface PersonnelLoad {
  personnelId: string;
  totalSubscribers: number;
}

/**
 * Automates the assignment of regions to personnel for a district.
 * Optimizes for:
 * 1. Fair distribution of subscriber counts (workload).
 * 2. Consecutive month rotation (a region should not go to the same reader from the previous month, if possible).
 */
export function solveAssignments(
  district: 'Polatlı' | 'Beypazarı',
  regions: Region[],
  personnel: Personnel[],
  lastMonthAssignments: Record<string, string> // regionId -> personnelId from previous month
): Assignment[] {
  // 1. Filter for selected district and active state
  const districtRegions = regions.filter((r) => r.district === district);
  const districtPersonnel = personnel.filter((p) => p.district === district && p.isActive);

  if (districtPersonnel.length === 0) {
    return [];
  }

  // 2. Sort regions by subscriber count descending to apply greedy Longest-Processing-Time-First
  const sortedRegions = [...districtRegions].sort((a, b) => b.subscribersCount - a.subscribersCount);

  // Initialize personnel loads
  const loads: Record<string, number> = {};
  for (const p of districtPersonnel) {
    loads[p.id] = 0;
  }

  const result: Assignment[] = [];

  // 3. Assign each region
  for (const region of sortedRegions) {
    // Who read this region last month?
    const lastMonthReaderId = lastMonthAssignments[region.id];

    // Find candidates who did NOT read this region last month
    const validCandidates = districtPersonnel.filter((p) => p.id !== lastMonthReaderId);

    let selectedPersonnelId = '';

    if (validCandidates.length > 0) {
      // Pick the valid candidate with the smallest current workload
      validCandidates.sort((a, b) => (loads[a.id] || 0) - (loads[b.id] || 0));
      selectedPersonnelId = validCandidates[0].id;
    } else {
      // Fallback: If no valid candidate exists (e.g., only 1 personnel exists, or all are blocked),
      // we must break the rule to ensure the region is read. Pick the person with lowest workload overall.
      const allSorted = [...districtPersonnel].sort((a, b) => (loads[a.id] || 0) - (loads[b.id] || 0));
      selectedPersonnelId = allSorted[0].id;
    }

    // Record the assignment
    result.push({
      regionId: region.id,
      personnelId: selectedPersonnelId,
    });

    // Update workload
    loads[selectedPersonnelId] = (loads[selectedPersonnelId] || 0) + region.subscribersCount;
  }

  return result;
}
