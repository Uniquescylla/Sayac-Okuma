import { Personnel, Region } from './types';

export const DEFAULT_PERSONNEL: Personnel[] = [
  // Polatlı - 8 Personnel
  { id: 'p1', name: 'Ahmet Yılmaz', district: 'Polatlı', isActive: true },
  { id: 'p2', name: 'Mehmet Demir', district: 'Polatlı', isActive: true },
  { id: 'p3', name: 'Can Toker', district: 'Polatlı', isActive: true },
  { id: 'p4', name: 'Mustafa Kaya', district: 'Polatlı', isActive: true },
  { id: 'p5', name: 'Elif Çelik', district: 'Polatlı', isActive: true },
  { id: 'p6', name: 'Esra Öztürk', district: 'Polatlı', isActive: true },
  { id: 'p7', name: 'Serkan Arslan', district: 'Polatlı', isActive: true },
  { id: 'p8', name: 'Burak Şahin', district: 'Polatlı', isActive: true },

  // Beypazarı - 4 Personnel
  { id: 'b1', name: 'Kemal Doğan', district: 'Beypazarı', isActive: true },
  { id: 'b2', name: 'Murat Yıldız', district: 'Beypazarı', isActive: true },
  { id: 'b3', name: 'Ayşe Kılıç', district: 'Beypazarı', isActive: true },
  { id: 'b4', name: 'Fatma Aydın', district: 'Beypazarı', isActive: true },
];

export const DEFAULT_REGIONS: Region[] = [
  // Polatlı - Şehitlik Mahallesi (14 Regions)
  { id: 'pr-s1', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 1', subscribersCount: 155, district: 'Polatlı' },
  { id: 'pr-s2', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 2', subscribersCount: 185, district: 'Polatlı' },
  { id: 'pr-s3', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 3', subscribersCount: 220, district: 'Polatlı' },
  { id: 'pr-s4', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 4', subscribersCount: 140, district: 'Polatlı' },
  { id: 'pr-s5', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 5', subscribersCount: 195, district: 'Polatlı' },
  { id: 'pr-s6', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 6', subscribersCount: 210, district: 'Polatlı' },
  { id: 'pr-s7', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 7', subscribersCount: 130, district: 'Polatlı' },
  { id: 'pr-s8', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 8', subscribersCount: 175, district: 'Polatlı' },
  { id: 'pr-s9', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 9', subscribersCount: 160, district: 'Polatlı' },
  { id: 'pr-s10', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 10', subscribersCount: 240, district: 'Polatlı' },
  { id: 'pr-s11', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 11', subscribersCount: 150, district: 'Polatlı' },
  { id: 'pr-s12', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 12', subscribersCount: 180, district: 'Polatlı' },
  { id: 'pr-s13', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 13', subscribersCount: 205, district: 'Polatlı' },
  { id: 'pr-s14', neighborhoodName: 'Şehitlik Mahallesi', regionName: 'Bölge 14', subscribersCount: 125, district: 'Polatlı' },

  // Polatlı - Cumhuriyet Mahallesi (8 Regions)
  { id: 'pr-c1', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 1', subscribersCount: 190, district: 'Polatlı' },
  { id: 'pr-c2', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 2', subscribersCount: 210, district: 'Polatlı' },
  { id: 'pr-c3', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 3', subscribersCount: 165, district: 'Polatlı' },
  { id: 'pr-c4', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 4', subscribersCount: 145, district: 'Polatlı' },
  { id: 'pr-c5', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 5', subscribersCount: 180, district: 'Polatlı' },
  { id: 'pr-c6', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 6', subscribersCount: 225, district: 'Polatlı' },
  { id: 'pr-c7', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 7', subscribersCount: 135, district: 'Polatlı' },
  { id: 'pr-c8', neighborhoodName: 'Cumhuriyet Mahallesi', regionName: 'Bölge 8', subscribersCount: 150, district: 'Polatlı' },

  // Polatlı - Gazi Mahallesi (6 Regions)
  { id: 'pr-g1', neighborhoodName: 'Gazi Mahallesi', regionName: 'Bölge 1', subscribersCount: 175, district: 'Polatlı' },
  { id: 'pr-g2', neighborhoodName: 'Gazi Mahallesi', regionName: 'Bölge 2', subscribersCount: 200, district: 'Polatlı' },
  { id: 'pr-g3', neighborhoodName: 'Gazi Mahallesi', regionName: 'Bölge 3', subscribersCount: 140, district: 'Polatlı' },
  { id: 'pr-g4', neighborhoodName: 'Gazi Mahallesi', regionName: 'Bölge 4', subscribersCount: 160, district: 'Polatlı' },
  { id: 'pr-g5', neighborhoodName: 'Gazi Mahallesi', regionName: 'Bölge 5', subscribersCount: 230, district: 'Polatlı' },
  { id: 'pr-g6', neighborhoodName: 'Gazi Mahallesi', regionName: 'Bölge 6', subscribersCount: 115, district: 'Polatlı' },

  // Beypazarı - Hacıkara Mahallesi (10 Regions)
  { id: 'br-h1', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 1', subscribersCount: 180, district: 'Beypazarı' },
  { id: 'br-h2', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 2', subscribersCount: 210, district: 'Beypazarı' },
  { id: 'br-h3', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 3', subscribersCount: 150, district: 'Beypazarı' },
  { id: 'br-h4', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 4', subscribersCount: 170, district: 'Beypazarı' },
  { id: 'br-h5', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 5', subscribersCount: 190, district: 'Beypazarı' },
  { id: 'br-h6', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 6', subscribersCount: 220, district: 'Beypazarı' },
  { id: 'br-h7', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 7', subscribersCount: 130, district: 'Beypazarı' },
  { id: 'br-h8', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 8', subscribersCount: 160, district: 'Beypazarı' },
  { id: 'br-h9', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 9', subscribersCount: 205, district: 'Beypazarı' },
  { id: 'br-h10', neighborhoodName: 'Hacıkara Mahallesi', regionName: 'Bölge 10', subscribersCount: 145, district: 'Beypazarı' },

  // Beypazarı - Zafer Mahallesi (6 Regions)
  { id: 'br-z1', neighborhoodName: 'Zafer Mahallesi', regionName: 'Bölge 1', subscribersCount: 195, district: 'Beypazarı' },
  { id: 'br-z2', neighborhoodName: 'Zafer Mahallesi', regionName: 'Bölge 2', subscribersCount: 160, district: 'Beypazarı' },
  { id: 'br-z3', neighborhoodName: 'Zafer Mahallesi', regionName: 'Bölge 3', subscribersCount: 230, district: 'Beypazarı' },
  { id: 'br-z4', neighborhoodName: 'Zafer Mahallesi', regionName: 'Bölge 4', subscribersCount: 140, district: 'Beypazarı' },
  { id: 'br-z5', neighborhoodName: 'Zafer Mahallesi', regionName: 'Bölge 5', subscribersCount: 175, district: 'Beypazarı' },
  { id: 'br-z6', neighborhoodName: 'Zafer Mahallesi', regionName: 'Bölge 6', subscribersCount: 120, district: 'Beypazarı' },
];

export const MONTH_NAMES = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
];
