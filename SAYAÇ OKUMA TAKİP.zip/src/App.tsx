import React, { useState, useEffect } from 'react';
import {
  Users,
  Map,
  Calendar,
  Sparkles,
  Printer,
  Download,
  Upload,
  AlertTriangle,
  CheckCircle2,
  Trash2,
  Plus,
  RotateCcw,
  Info,
  ChevronRight,
  TrendingUp,
  FileSpreadsheet,
  Check,
  User,
  PlusCircle,
  HelpCircle
} from 'lucide-react';
import { Personnel, Region, MonthRecord, Assignment } from './types';
import { DEFAULT_PERSONNEL, DEFAULT_REGIONS, MONTH_NAMES } from './sampleData';
import { solveAssignments } from './utils/assignmentSolver';

export default function App() {
  // --- Data States ---
  const [personnel, setPersonnel] = useState<Personnel[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [records, setRecords] = useState<MonthRecord[]>([]);

  // --- UI States ---
  const [selectedDistrict, setSelectedDistrict] = useState<'Polatlı' | 'Beypazarı'>('Polatlı');
  const [activeTab, setActiveTab] = useState<'planning' | 'personnel' | 'regions' | 'history'>('planning');
  
  // State for alert banner
  const [alertMessage, setAlertMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  // --- Temporary Add Form States ---
  const [newPersName, setNewPersName] = useState('');
  const [newRegNeighborhood, setNewRegNeighborhood] = useState('');
  const [newRegName, setNewRegName] = useState('');
  const [newRegSubscribers, setNewRegSubscribers] = useState<number | ''>('');

  // Bulk input text fields
  const [bulkPersonnelText, setBulkPersonnelText] = useState('');
  const [bulkRegionsText, setBulkRegionsText] = useState('');
  const [showBulkModal, setShowBulkModal] = useState<'personnel' | 'regions' | null>(null);

  // --- Active Planning States ---
  const [planningYear, setPlanningYear] = useState(2026);
  // Default month: June (index 5)
  const [planningMonthIndex, setPlanningMonthIndex] = useState(5);
  // Assigned personnel selection list for current temporary planning session
  // Maps regionId -> personnelId (holds active uncommitted planning assignments)
  const [tempAssignments, setTempAssignments] = useState<Record<string, string>>({});
  const [selectedReferenceRecordId, setSelectedReferenceRecordId] = useState<string>('auto');

  // --- Load Initial State from LocalStorage ---
  useEffect(() => {
    const cachedPersonnel = localStorage.getItem('gas_planner_personnel');
    const cachedRegions = localStorage.getItem('gas_planner_regions');
    const cachedRecords = localStorage.getItem('gas_planner_records');

    if (cachedPersonnel && cachedRegions) {
      setPersonnel(JSON.parse(cachedPersonnel));
      setRegions(JSON.parse(cachedRegions));
      if (cachedRecords) {
        setRecords(JSON.parse(cachedRecords));
      }
    } else {
      // Load standard defaults
      setPersonnel(DEFAULT_PERSONNEL);
      setRegions(DEFAULT_REGIONS);
      setRecords(generatePreloadedHistory());
      // Save them immediately to cache
      localStorage.setItem('gas_planner_personnel', JSON.stringify(DEFAULT_PERSONNEL));
      localStorage.setItem('gas_planner_regions', JSON.stringify(DEFAULT_REGIONS));
      localStorage.setItem('gas_planner_records', JSON.stringify(generatePreloadedHistory()));
    }
  }, []);

  // Sync state helpers
  const savePersonnel = (updated: Personnel[]) => {
    setPersonnel(updated);
    localStorage.setItem('gas_planner_personnel', JSON.stringify(updated));
  };

  const saveRegions = (updated: Region[]) => {
    setRegions(updated);
    localStorage.setItem('gas_planner_regions', JSON.stringify(updated));
  };

  const saveRecords = (updated: MonthRecord[]) => {
    setRecords(updated);
    localStorage.setItem('gas_planner_records', JSON.stringify(updated));
  };

  // Generate realistic histories to make the page immediately meaningful
  function generatePreloadedHistory(): MonthRecord[] {
    // Generate records for Nisan 2026 ("2026-04") and Mayis 2026 ("2026-05") to test the rotation engine right away!
    const items: MonthRecord[] = [];

    // 1. Polatlı - Mayıs 2026
    const polatliRegions = DEFAULT_REGIONS.filter(r => r.district === 'Polatlı');
    const polatliPers = DEFAULT_PERSONNEL.filter(p => p.district === 'Polatlı');
    const polatliAssignments: Assignment[] = [];
    
    // Assign indices deterministically for demonstration
    polatliRegions.forEach((r, idx) => {
      const pIndex = idx % polatliPers.length;
      polatliAssignments.push({
        regionId: r.id,
        personnelId: polatliPers[pIndex].id
      });
    });

    items.push({
      id: '2026-05-Polatlı',
      monthLabel: 'Mayıs 2026',
      district: 'Polatlı',
      assignments: polatliAssignments,
      createdAt: new Date('2026-05-01T08:00:00Z').toISOString()
    });

    // 2. Beypazarı - Mayıs 2026
    const beypazariRegions = DEFAULT_REGIONS.filter(r => r.district === 'Beypazarı');
    const beypazariPers = DEFAULT_PERSONNEL.filter(p => p.district === 'Beypazarı');
    const beypazariAssignments: Assignment[] = [];

    beypazariRegions.forEach((r, idx) => {
      const pIndex = idx % beypazariPers.length;
      beypazariAssignments.push({
        regionId: r.id,
        personnelId: beypazariPers[pIndex].id
      });
    });

    items.push({
      id: '2026-05-Beypazarı',
      monthLabel: 'Mayıs 2026',
      district: 'Beypazarı',
      assignments: beypazariAssignments,
      createdAt: new Date('2026-05-01T08:30:00Z').toISOString()
    });

    return items;
  }

  // --- Reset All Data Button ---
  const handleResetToDefaults = () => {
    if (window.confirm('Tüm sistemi sıfırlamak ve orijinal Polatlı & Beypazarı örnek verilerini yüklemek istediğinizden emin misiniz? Yapılan tüm değişiklikler ve geçmiş silinecektir.')) {
      setPersonnel(DEFAULT_PERSONNEL);
      setRegions(DEFAULT_REGIONS);
      const preloaded = generatePreloadedHistory();
      setRecords(preloaded);
      
      localStorage.setItem('gas_planner_personnel', JSON.stringify(DEFAULT_PERSONNEL));
      localStorage.setItem('gas_planner_regions', JSON.stringify(DEFAULT_REGIONS));
      localStorage.setItem('gas_planner_records', JSON.stringify(preloaded));

      showNotification('Sistem varsayılan ayarlara başarıyla sıfırlandı.', 'success');
      setTempAssignments({});
    }
  };

  const showNotification = (text: string, type: 'success' | 'info' | 'error') => {
    setAlertMessage({ text, type });
    setTimeout(() => {
      setAlertMessage((prev) => (prev?.text === text ? null : prev));
    }, 4500);
  };

  // --- Filtering items by selected district ---
  const activePersonnel = personnel.filter(p => p.district === selectedDistrict);
  const activeRegions = regions.filter(r => r.district === selectedDistrict);

  // --- Find Last Assigned Month Reference ---
  // If the user wants to auto-detect, we search records in this district ordered by date descending
  // which is prior to the currently selected planning month
  const getReferenceRecordId = (): string | null => {
    if (records.length === 0) return null;

    const districtRecords = records.filter(r => r.district === selectedDistrict);
    if (districtRecords.length === 0) return null;

    if (selectedReferenceRecordId !== 'auto') {
      const checkRecord = districtRecords.find(r => r.id === selectedReferenceRecordId);
      return checkRecord ? checkRecord.id : null;
    }

    // Auto behavior: Find the most recent record whose year-month is before our planning month
    const targetYM = `${planningYear}-${String(planningMonthIndex + 1).padStart(2, '0')}`;
    
    // Sort district records chronologically descending by parsing their id prefixes or dates
    const chronRecords = [...districtRecords].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    
    // Find first record that was created prior to target index or we just take the absolute latest one!
    const priorRecord = chronRecords.find(r => {
      const parts = r.id.split('-'); // e.g. ["2026", "05", "Polatlı"]
      if (parts.length >= 2) {
        const recordYM = `${parts[0]}-${parts[1]}`;
        return recordYM < targetYM;
      }
      return true;
    });

    return priorRecord ? priorRecord.id : (chronRecords[0]?.id || null);
  };

  const currentReferenceRecordId = getReferenceRecordId();
  const currentReferenceRecord = records.find(r => r.id === currentReferenceRecordId);

  // Map of regionId to last personnelId for swift lookup during assignment & warnings
  const referenceAssignmentsMap = React.useMemo(() => {
    const map: Record<string, string> = {};
    if (currentReferenceRecord) {
      for (const a of currentReferenceRecord.assignments) {
        map[a.regionId] = a.personnelId;
      }
    }
    return map;
  }, [currentReferenceRecord]);

  // --- Planning Actions ---
  const handleAutoAssign = () => {
    const activeStaff = activePersonnel.filter(p => p.isActive);
    if (activeStaff.length === 0) {
      showNotification('Otomatik atama yapabilmek için en az 1 adet aktif personel bulunmalıdır.', 'error');
      return;
    }
    if (activeRegions.length === 0) {
      showNotification('Otomatik atama yapılacak hiçbir bölge tanımlanmamış.', 'error');
      return;
    }

    const sol = solveAssignments(selectedDistrict, regions, personnel, referenceAssignmentsMap);
    
    // Convert solutions payload to tempAssignments state
    const newTemp: Record<string, string> = {};
    for (const assignment of sol) {
      newTemp[assignment.regionId] = assignment.personnelId;
    }

    setTempAssignments(newTemp);
    showNotification('Okuma bölgeleri, personelin geçmiş ay dağılımı ve iş yükü hesaba katılarak en adil şekilde otomatik atandı!', 'success');
  };

  const handleManualAssignChange = (regionId: string, personnelId: string) => {
    setTempAssignments(prev => ({
      ...prev,
      [regionId]: personnelId
    }));
  };

  const handleSavePlanning = () => {
    // Save current planning session into permanent history record
    const monthLabel = `${MONTH_NAMES[planningMonthIndex]} ${planningYear}`;
    const monthId = `${planningYear}-${String(planningMonthIndex + 1).padStart(2, '0')}-${selectedDistrict}`;

    // Verify all regions are assigned
    const unassignedRegions = activeRegions.filter(r => !tempAssignments[r.id]);
    if (unassignedRegions.length > 0) {
      if (!window.confirm(`${unassignedRegions.length} bölgeye henüz personel atanmadı. Yine de bu atama planını kaydetmek istiyor musunuz?`)) {
        return;
      }
    }

    // Convert tempAssignments to array
    const saveList: Assignment[] = [];
    activeRegions.forEach(r => {
      if (tempAssignments[r.id]) {
        saveList.push({
          regionId: r.id,
          personnelId: tempAssignments[r.id]
        });
      }
    });

    const newRecord: MonthRecord = {
      id: monthId,
      monthLabel,
      district: selectedDistrict,
      assignments: saveList,
      createdAt: new Date().toISOString()
    };

    // Remove duplicates if already exists for same month-district
    const filteredRecords = records.filter(r => r.id !== monthId);
    const updatedRecords = [newRecord, ...filteredRecords];
    
    saveRecords(updatedRecords);
    showNotification(`${monthLabel} dönemi ${selectedDistrict} planı başarıyla kaydedildi!`, 'success');
  };

  // --- Personnel Actions ---
  const handleAddPersonnel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPersName.trim()) return;

    const newPerson: Personnel = {
      id: `pers-${Date.now()}`,
      name: newPersName.trim(),
      district: selectedDistrict,
      isActive: true
    };

    savePersonnel([...personnel, newPerson]);
    setNewPersName('');
    showNotification(`Yeni personel "${newPerson.name}" eklendi.`, 'success');
  };

  const togglePersonnelStatus = (id: string) => {
    const updated = personnel.map(p => {
      if (p.id === id) {
        return { ...p, isActive: !p.isActive };
      }
      return p;
    });
    savePersonnel(updated);
    showNotification('Personel çalışma durumu güncellendi.', 'info');
  };

  const handleDeletePersonnel = (id: string, name: string) => {
    if (window.confirm(`"${name}" adlı personeli silmek istediğinizden emin misiniz?`)) {
      const updated = personnel.filter(p => p.id !== id);
      savePersonnel(updated);
      showNotification(`"${name}" silindi.`, 'info');
    }
  };

  // --- Regions Actions ---
  const handleAddRegion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRegNeighborhood.trim() || !newRegName.trim() || newRegSubscribers === '') return;

    const newReg: Region = {
      id: `reg-${Date.now()}`,
      neighborhoodName: newRegNeighborhood.trim(),
      regionName: newRegName.trim(),
      subscribersCount: Number(newRegSubscribers),
      district: selectedDistrict
    };

    saveRegions([...regions, newReg]);
    setNewRegNeighborhood('');
    setNewRegName('');
    setNewRegSubscribers('');
    showNotification(`Yeni bölge "${newReg.neighborhoodName} ${newReg.regionName}" başarıyla eklendi.`, 'success');
  };

  const handleDeleteRegion = (id: string, label: string) => {
    if (window.confirm(`"${label}" bölgesini silmek istediğinizden emin misiniz?`)) {
      const updated = regions.filter(r => r.id !== id);
      saveRegions(updated);
      showNotification(`Bölge silindi: ${label}`, 'info');
    }
  };

  // --- Bulk Input Actions ---
  const handleImportPersonnelBulk = () => {
    if (!bulkPersonnelText.trim()) return;
    
    const lines = bulkPersonnelText.split('\n');
    const added: Personnel[] = [];

    lines.forEach((line, index) => {
      const name = line.trim();
      if (name) {
        added.push({
          id: `pers-bulk-${Date.now()}-${index}`,
          name,
          district: selectedDistrict,
          isActive: true
        });
      }
    });

    if (added.length > 0) {
      savePersonnel([...personnel, ...added]);
      showNotification(`${added.length} adet yeni personel toplu olarak eklendi!`, 'success');
    }
    
    setBulkPersonnelText('');
    setShowBulkModal(null);
  };

  const handleImportRegionsBulk = () => {
    if (!bulkRegionsText.trim()) return;

    // Expected format: Neighborhood \t RegionName/No \t SubscribersCount
    // or Neighborhood, RegionName, SubscribersCount
    const lines = bulkRegionsText.split('\n');
    const added: Region[] = [];

    lines.forEach((line, index) => {
      const cleanLine = line.trim();
      if (!cleanLine) return;

      // Handle tab, semicolon, comma or space separated formats
      let parts = cleanLine.split('\t');
      if (parts.length < 3) parts = cleanLine.split(';');
      if (parts.length < 3) parts = cleanLine.split(',');

      if (parts.length >= 3) {
        const neighborhoodName = parts[0].trim();
        const regionName = parts[1].trim();
        const subscribersCount = parseInt(parts[2].replace(/\D/g, ''), 10);

        if (neighborhoodName && regionName && !isNaN(subscribersCount)) {
          added.push({
            id: `reg-bulk-${Date.now()}-${index}`,
            neighborhoodName,
            regionName,
            subscribersCount,
            district: selectedDistrict
          });
        }
      } else {
        // Fallback for simple neighborhood naming with regions logic
        // "Şehitlik Bölge 1 120"
        const lastSpaceIdx = cleanLine.lastIndexOf(' ');
        if (lastSpaceIdx !== -1) {
          const subscribersPart = cleanLine.substring(lastSpaceIdx + 1).trim();
          const subscribersCount = parseInt(subscribersPart.replace(/\D/g, ''), 10);
          
          const textPart = cleanLine.substring(0, lastSpaceIdx).trim();
          const words = textPart.split(' ');
          
          if (words.length >= 2 && !isNaN(subscribersCount)) {
            const regionName = words.pop() || 'Bölge';
            const neighborhoodName = words.join(' ');
            
            added.push({
              id: `reg-bulk-${Date.now()}-${index}`,
              neighborhoodName,
              regionName,
              subscribersCount,
              district: selectedDistrict
            });
          }
        }
      }
    });

    if (added.length > 0) {
      saveRegions([...regions, ...added]);
      showNotification(`${added.length} adet yeni bölge toplu olarak sisteme eklendi!`, 'success');
    }

    setBulkRegionsText('');
    setShowBulkModal(null);
  };

  // --- Deleting History Records ---
  const handleDeleteRecord = (recordId: string, monthLabel: string) => {
    if (window.confirm(`"${monthLabel}" dönemine ait kayıtları arşivden silmek istediğinize emin misiniz?`)) {
      const updated = records.filter(r => r.id !== recordId);
      saveRecords(updated);
      showNotification(`"${monthLabel}" dönem kaydı silindi.`, 'info');
    }
  };

  // --- Export / Import Backup Data System ---
  const handleExportBackup = () => {
    try {
      const dataStr = JSON.stringify({
        personnel,
        regions,
        records
      }, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = `dogalgaz_sayac_okuma_yedek_${new Date().toISOString().substring(0, 10)}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      showNotification('Tüm sistem verileri (personel, bölgeler ve geçmiş) JSON yedek dosyası olarak başarıyla indirildi!', 'success');
    } catch (err) {
      showNotification('Yedek dışa aktarılırken bir hata oluştu.', 'error');
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], "UTF-8");
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed && Array.isArray(parsed.personnel) && Array.isArray(parsed.regions) && Array.isArray(parsed.records)) {
            savePersonnel(parsed.personnel);
            saveRegions(parsed.regions);
            saveRecords(parsed.records);
            showNotification('Yedek dosyası başarıyla yüklendi! Tüm personeller, mahalleler ve geçmiş veriler geri yüklendi.', 'success');
          } else {
            showNotification('Geçersiz yedek dosyası formatı. Dosya geçerli bir sistem yedeği içermelidir.', 'error');
          }
        } catch (err) {
          showNotification('Dosya okunurken veya ayrıştırılırken hata oluştu. Lütfen geçerli bir yedek dosyası seçin.', 'error');
        }
      };
    }
  };

  // --- Workload Metrics calculations for the Current Assignment ---
  // Calculates the current workload metric indicators for balancing visualization
  const workloadStats = React.useMemo(() => {
    const activeStaff = activePersonnel.filter(p => p.isActive);
    if (activeStaff.length === 0) return { breakdown: {}, list: [], avg: 0, min: 0, max: 0, stdDev: 0 };

    const breakdown: Record<string, { count: number; subs: number; regions: Array<{ neighborhood: string; name: string; subs: number }> }> = {};
    for (const p of activeStaff) {
      breakdown[p.id] = { count: 0, subs: 0, regions: [] };
    }

    activeRegions.forEach((r) => {
      const assignedPersId = tempAssignments[r.id];
      if (assignedPersId && breakdown[assignedPersId]) {
        breakdown[assignedPersId].count += 1;
        breakdown[assignedPersId].subs += r.subscribersCount;
        breakdown[assignedPersId].regions.push({
          neighborhood: r.neighborhoodName,
          name: r.regionName,
          subs: r.subscribersCount
        });
      }
    });

    const list = activeStaff.map(p => ({
      id: p.id,
      name: p.name,
      regionsCount: breakdown[p.id].count,
      totalSubscribers: breakdown[p.id].subs,
      regionsList: breakdown[p.id].regions
    }));

    const subsList = list.map(item => item.totalSubscribers);
    const sum = subsList.reduce((acc, v) => acc + v, 0);
    const avg = Math.round(sum / activeStaff.length);
    const min = subsList.length > 0 ? Math.min(...subsList) : 0;
    const max = subsList.length > 0 ? Math.max(...subsList) : 0;

    // Standard deviation for visual balancing score
    const mean = sum / activeStaff.length;
    const squareDiffs = subsList.map((val) => Math.pow(val - mean, 2));
    const avgSquareDiff = squareDiffs.reduce((acc, v) => acc + v, 0) / activeStaff.length;
    const stdDev = Math.round(Math.sqrt(avgSquareDiff));

    return {
      breakdown,
      list,
      avg,
      min,
      max,
      stdDev
    };
  }, [activePersonnel, activeRegions, tempAssignments]);

  const totalAssignedRegionsCount = Object.keys(tempAssignments).filter(id => {
    // Ensure region still exists and is in current district
    const reg = regions.find(r => r.id === id);
    return reg && reg.district === selectedDistrict && tempAssignments[id];
  }).length;

  const totalActiveRegionsCount = activeRegions.length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans transition-colors duration-300">
      
      {/* --- TOP BAR / MAIN NAV --- */}
      <header className="bg-slate-900 text-white shadow-xl no-print">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Logo & Headline */}
          <div className="flex items-center gap-3">
            <div className="bg-amber-500 text-slate-950 p-2.5 rounded-lg shadow-inner flex items-center justify-center font-bold">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
                Doğal Gaz Sayaç Okuma Planlayıcı
                <span className="text-xs bg-amber-500/20 text-amber-400 font-semibold px-2 py-0.5 rounded-full border border-amber-500/30">
                  Uzatman Önleyici v1.2
                </span>
              </h1>
              <p className="text-xs text-slate-400">
                Polatlı & Beypazarı İlçeleri Aylık Ardışık Bölge Rotasyonu ve İş Yükü Dengeleme Sistemi
              </p>
            </div>
          </div>

          {/* Quick Actions & District Switcher */}
          <div className="flex items-center flex-wrap gap-2">
            
            {/* District Pick Button */}
            <div className="bg-slate-800 p-1 rounded-lg border border-slate-700 flex gap-1">
              <button
                onClick={() => {
                  setSelectedDistrict('Polatlı');
                  setTempAssignments({}); // Clear plan screen for safe transition
                }}
                className={`px-4 py-1.5 rounded-md text-xs font-semibold tracking-wide transition-all ${
                  selectedDistrict === 'Polatlı'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Polatlı (8 Pres)
              </button>
              <button
                onClick={() => {
                  setSelectedDistrict('Beypazarı');
                  setTempAssignments({}); // Clear plan screen for safe transition
                }}
                className={`px-4 py-1.5 rounded-md text-xs font-semibold tracking-wide transition-all ${
                  selectedDistrict === 'Beypazarı'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Beypazarı (4 Pres)
              </button>
            </div>

            {/* Clear Database Button */}
            <button
              id="reset-state-btn"
              onClick={handleResetToDefaults}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
              title="Örnek verileri yükle veya her şeyi sıfırla"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Sıfırla
            </button>
          </div>

        </div>
      </header>

      {/* --- NOTIFICATION SYSTEM BAR --- */}
      {alertMessage && (
        <div className="bg-slate-100 border-b border-slate-200 no-print transition-all">
          <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8">
            <div className={`flex items-center gap-2 text-sm font-semibold rounded-lg px-4 py-2.5 ${
              alertMessage.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
              alertMessage.type === 'error' ? 'bg-rose-50 text-rose-800 border border-rose-200' :
              'bg-blue-50 text-blue-800 border border-blue-200'
            }`}>
              {alertMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0" />}
              {alertMessage.type === 'error' && <AlertTriangle className="w-4 h-4 shrink-0" />}
              {alertMessage.type === 'info' && <Info className="w-4 h-4 shrink-0" />}
              <span>{alertMessage.text}</span>
            </div>
          </div>
        </div>
      )}

      {/* --- APP MAIN CONTENT --- */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 sm:px-6 lg:px-8 flex flex-col gap-6">

        {/* --- DYNAMIC STATS CARD (WORKSPACE GLANCE) --- */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 sm:p-6 grid grid-cols-2 md:grid-cols-4 gap-4 no-print select-none">
          
          <div className="border-r border-slate-100 last:border-0 pr-4">
            <span className="text-xs text-slate-400 font-semibold block uppercase tracking-wider">Seçili İlçe</span>
            <div className="text-xl font-bold text-slate-900 mt-1 flex items-center gap-1.5">
              <ChevronRight className="w-4 h-4 text-amber-500" />
              {selectedDistrict}
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">Hizmet Bölgesi</span>
          </div>

          <div className="border-r border-slate-100 last:border-0 pr-4 md:pl-2">
            <span className="text-xs text-slate-400 font-semibold block uppercase tracking-wider">Kayıtlı Personel</span>
            <div className="text-xl font-bold text-slate-900 mt-1 flex items-center gap-2">
              <Users className="text-slate-500 w-5 h-5" />
              {activePersonnel.length} Kişi
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              {activePersonnel.filter(p => p.isActive).length} aktif okuyucu saha personeli
            </span>
          </div>

          <div className="border-r border-slate-100 last:border-0 pr-4 md:pl-2">
            <span className="text-xs text-slate-400 font-semibold block uppercase tracking-wider">Toplam Bölge & Abone</span>
            <div className="text-xl font-bold text-slate-900 mt-1 flex flex-col sm:flex-row sm:items-baseline gap-1">
              <span>{activeRegions.length} Bölge</span>
              <span className="text-xs text-slate-500">
                ({activeRegions.reduce((sum, r) => sum + r.subscribersCount, 0).toLocaleString()} Abone)
              </span>
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              Mahallelerde okunan sayaç hacmi
            </span>
          </div>

          <div className="md:pl-2">
            <span className="text-xs text-slate-400 font-semibold block uppercase tracking-wider font-mono">Dönem Rotasyonu</span>
            <div className="text-xl font-bold mt-1 text-slate-900 flex items-center gap-1.5">
              <Calendar className="text-amber-500 w-5 h-5 shrink-0" />
              <span>{MONTH_NAMES[planningMonthIndex]} {planningYear}</span>
            </div>
            <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block flex items-center gap-0.5">
              <Check className="w-3 h-3" /> Çakışma denetimi devrede
            </span>
          </div>

        </div>

        {/* --- PRIMARY TAB NAVIGATION BAR --- */}
        <div className="bg-slate-100 p-1 rounded-xl border border-slate-200 flex flex-wrap gap-1 no-print">
          <button
            onClick={() => setActiveTab('planning')}
            className={`flex-1 min-w-[124px] py-3 px-4 rounded-lg font-semibold text-xs tracking-wide transition-all flex items-center justify-center gap-2 ${
              activeTab === 'planning'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            Bölge Atama Masası
          </button>
          
          <button
            onClick={() => setActiveTab('personnel')}
            className={`flex-1 min-w-[124px] py-3 px-4 rounded-lg font-semibold text-xs tracking-wide transition-all flex items-center justify-center gap-2 ${
              activeTab === 'personnel'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Users className="w-4 h-4 text-slate-500" />
            Personel Yönetimi ({activePersonnel.length})
          </button>

          <button
            onClick={() => setActiveTab('regions')}
            className={`flex-1 min-w-[124px] py-3 px-4 rounded-lg font-semibold text-xs tracking-wide transition-all flex items-center justify-center gap-2 ${
              activeTab === 'regions'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Map className="w-4 h-4 text-indigo-500" />
            Bölgeler & Mahalleler ({activeRegions.length})
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 min-w-[124px] py-3 px-4 rounded-lg font-semibold text-xs tracking-wide transition-all flex items-center justify-center gap-2 ${
              activeTab === 'history'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <Calendar className="w-4 h-4 text-emerald-500" />
            Geçmiş Dönem Kayıtları
          </button>
        </div>

        {/* ========================================================= */}
        {/* TAB: ATAMA VE PLANLAMA MASASI                             */}
        {/* ========================================================= */}
        {activeTab === 'planning' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left side column: Controller & Reference Data Panel */}
            <div className="lg:col-span-4 flex flex-col gap-6 no-print">
              
              {/* Box 1: Assignment target selectors */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col gap-4">
                <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-amber-500" />
                  Atama Dönemi Seçin
                </h3>

                {/* Month Pickers */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <label className="text-[10px] text-slate-400 font-bold tracking-wider block mb-1">Dönem Ayı</label>
                    <select
                      value={planningMonthIndex}
                      onChange={(e) => {
                        setPlanningMonthIndex(Number(e.target.value));
                        setTempAssignments({}); // Clear plan to avoid outdated views
                      }}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg p-2 font-medium focus:outline-none focus:ring-1 focus:ring-amber-500"
                    >
                      {MONTH_NAMES.map((m, idx) => (
                        <option key={idx} value={idx}>{m}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 font-bold tracking-wider block mb-1">Yıl</label>
                    <select
                      value={planningYear}
                      onChange={(e) => {
                        setPlanningYear(Number(e.target.value));
                        setTempAssignments({}); 
                      }}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg p-2 font-medium focus:outline-none focus:ring-1 focus:ring-amber-500"
                    >
                      <option value={2026}>2026</option>
                      <option value={2027}>2027</option>
                    </select>
                  </div>
                </div>

                {/* Rotation Reference Selection */}
                <div>
                  <label className="text-[10px] text-slate-400 font-bold tracking-wider block mb-1 flex items-center gap-1">
                    Rotasyon Kaynak Referansı (Önceki Ay)
                    <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-help" title="Sistem, bir önceki ay bölgeyi okuyan personelin bu ay çakışıp çakışmadığını tespit etmek için bu arşiv kaydına bakar." />
                  </label>
                  <select
                    value={selectedReferenceRecordId}
                    onChange={(e) => setSelectedReferenceRecordId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg p-2 font-medium focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="auto">Otomatik Tespit Et (Tavsiye Edilen)</option>
                    {records.filter(r => r.district === selectedDistrict).map(r => (
                      <option key={r.id} value={r.id}>{r.monthLabel} Planı</option>
                    ))}
                    {records.filter(r => r.district === selectedDistrict).length === 0 && (
                      <option disabled>Arşiv kaydı bulunamadı</option>
                    )}
                  </select>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    {currentReferenceRecord ? (
                      <span className="text-emerald-600 font-semibold">
                        ✓ Bulunan kriter: {currentReferenceRecord.monthLabel} ataması baz alınacaktır.
                      </span>
                    ) : (
                      <span className="text-amber-600 font-medium">
                        ⚠ Karşılaştırılacak geçmiş dönem kaydı yok. Rotasyon engelleme bir sonraki işlemden itibaren aktifleşecektir.
                      </span>
                    )}
                  </span>
                </div>

                {/* Big Action Button */}
                <div className="pt-2">
                  <button
                    onClick={handleAutoAssign}
                    className="w-full bg-slate-900 hover:bg-slate-800 text-amber-400 font-bold text-xs py-3 rounded-lg flex items-center justify-center gap-2 border border-slate-700 shadow-md transform hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 animate-bounce" />
                    OTOMATİK ROTASYON ATAMASI YAP
                  </button>
                  <p className="text-[10px] text-slate-400 text-center mt-2 font-mono">
                    Hataları sıfır çakışma ve tam yük dengesi ile çözer.
                  </p>
                </div>

              </div>

              {/* Box 2: Balancing Statistics (Workload) */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col gap-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-500" />
                    İş Yükü Dengesi Analizi
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 bg-slate-100 font-bold rounded-lg text-slate-600">
                    {totalAssignedRegionsCount} / {totalActiveRegionsCount} Atandı
                  </span>
                </div>

                {/* Numerical indexes */}
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] text-slate-400 font-bold block mb-0.5 uppercase">Ortalama Yük</span>
                    <span className="text-md font-extrabold text-slate-800">
                      {workloadStats.avg.toLocaleString()}
                    </span>
                    <span className="text-[9px] text-slate-400 block mt-0.5">Sayaç Abone Puanı</span>
                  </div>
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="text-[10px] text-slate-400 font-bold block mb-0.5 uppercase">Sapma Oranı</span>
                    <span className={`text-md font-extrabold block ${
                      workloadStats.stdDev < 150 ? 'text-emerald-600' :
                      workloadStats.stdDev < 350 ? 'text-amber-600' :
                      'text-rose-600'
                    }`}>
                      ± {workloadStats.stdDev}
                    </span>
                    <span className="text-[9px] text-slate-400 block mt-0.5">Denge Standart Sapması</span>
                  </div>
                </div>

                {/* Personnel meters */}
                <div className="flex flex-col gap-3 mt-1 max-h-56 overflow-y-auto">
                  {workloadStats.list.map((item) => {
                    const percentage = workloadStats.max > 0 ? (item.totalSubscribers / workloadStats.max) * 100 : 0;
                    
                    // Color depending on proximity to average load
                    const deviation = Math.abs(item.totalSubscribers - workloadStats.avg);
                    const isBalanced = deviation < (workloadStats.avg * 0.20) || item.totalSubscribers === 0;

                    return (
                      <div key={item.id} className="text-xs">
                        <div className="flex items-center justify-between text-slate-700 font-semibold mb-1">
                          <span className="flex items-center gap-1.5 font-bold">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                            {item.name}
                          </span>
                          <span className="font-mono text-slate-500">
                            {item.regionsCount} bölge ({item.totalSubscribers.toLocaleString()} Abone)
                          </span>
                        </div>
                        
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
                          <div
                            style={{ width: `${Math.max(percentage, 5)}%` }}
                            className={`h-full rounded-full transition-all duration-500 ${
                              item.totalSubscribers === 0 ? 'bg-slate-300' :
                              isBalanced ? 'bg-emerald-500' : 'bg-amber-500'
                            }`}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                  
                  {workloadStats.list.length === 0 && (
                    <div className="text-slate-400 text-xs italic text-center py-4">
                      Aktif personel bulunamadı.
                    </div>
                  )}
                </div>

                <div className="bg-amber-50 p-3 rounded-lg border border-amber-100 text-[11px] text-amber-900 leading-relaxed">
                  <div className="font-bold flex items-center gap-1 mb-1">
                    <Info className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    Sayaç Okuma Adalet Kuralı:
                  </div>
                  Sistem, bölgelerdeki abone yükünü personeller arasında dengelerken aynı zamanda personelin bir önceki ay okuduğu mahalleye geçiş çakışmalarını tamamen önleyecek rotasyon hesapları yapar.
                </div>

              </div>

            </div>

            {/* Right side column: Region list & Assignments dashboard */}
            <div className="lg:col-span-8 flex flex-col gap-6">

              {/* Main Workspace Frame */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
                
                {/* Header Actions */}
                <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-amber-500" />
                      {selectedDistrict} Atama Masası
                    </h2>
                    <p className="text-xs text-slate-500">
                      Bölgelere okuyucu personel atamalarını aşağıdan revize edip kaydedebilirsiniz.
                    </p>
                  </div>

                  {/* Print and Save Permanent actions */}
                  <div className="flex items-center gap-2 no-print self-end sm:self-auto">
                    {/* Print Button */}
                    <button
                      onClick={() => window.print()}
                      className="px-3.5 py-1.5 bg-white border border-slate-200 hover:border-slate-300 rounded-lg text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                    >
                      <Printer className="w-4 h-4 text-slate-500" />
                      Yazdır / PDF Yap
                    </button>

                    {/* Commit/Save Button */}
                    <button
                      onClick={handleSavePlanning}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      Planı Kaydet
                    </button>
                  </div>
                </div>

                {/* Conflict Explanation Guide bar */}
                <div className="px-4 py-3 bg-slate-900 text-white text-[11px] font-mono flex flex-wrap gap-4 items-center justify-between no-print">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0 inline-block"></span>
                    <span>Kırmızı Alan: Önceki Ay Ardışık Çakışma Uyarısı (İstenmeyen Durum)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0 inline-block"></span>
                    <span>Yeşil Alan: Güvenli Rotasyon</span>
                  </div>
                </div>

                {/* Regions Grid Assignments List */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-400 font-bold tracking-wider uppercase select-none">
                        <th className="py-3 px-4">Sıra No</th>
                        <th className="py-3 px-4">Mahalle ve Okuma Bölgesi</th>
                        <th className="py-3 px-4 text-right">Abone Sayısı</th>
                        <th className="py-3 px-4 no-print text-center">Önceki Ay Kim Okudu?</th>
                        <th className="py-3 px-4">Bu Ay Atanan Personel</th>
                        <th className="py-3 px-4 text-center">Durum</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {activeRegions.map((region, index) => {
                        const assignedPersId = tempAssignments[region.id] || '';
                        
                        // Reference reader ID from last month lookup
                        const lastMonthStaffId = referenceAssignmentsMap[region.id];
                        const lastMonthStaff = personnel.find(p => p.id === lastMonthStaffId);

                        // Conflict checks
                        const hasConflict = assignedPersId && lastMonthStaffId && assignedPersId === lastMonthStaffId;

                        return (
                          <tr
                            key={region.id}
                            className={`hover:bg-slate-50 transition-colors ${
                              hasConflict ? 'bg-red-50/50' : ''
                            }`}
                          >
                            {/* Row Index */}
                            <td className="py-3 px-4 font-mono text-slate-400 w-12">
                              #{String(index + 1).padStart(2, '0')}
                            </td>

                            {/* Neighborhood Name & Region Badge */}
                            <td className="py-3 px-4">
                              <div className="font-semibold text-slate-900">{region.neighborhoodName}</div>
                              <div className="text-[11px] text-slate-500">{region.regionName}</div>
                            </td>

                            {/* Subscribers load count */}
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-700">
                              {region.subscribersCount.toLocaleString()}
                            </td>

                            {/* Last Month Reference Reader Indicator */}
                            <td className="py-3 px-4 no-print text-center">
                              {lastMonthStaff ? (
                                <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                                  <User className="w-3 h-3 text-slate-400" />
                                  {lastMonthStaff.name}
                                </span>
                              ) : (
                                <span className="text-slate-400 italic text-[11px]">- Veri Yok -</span>
                              )}
                            </td>

                            {/* Current Assigned Personnel Selector */}
                            <td className="py-3 px-4">
                              <select
                                value={assignedPersId}
                                onChange={(e) => handleManualAssignChange(region.id, e.target.value)}
                                className={`w-full max-w-[200px] border text-xs rounded-md p-1.5 font-medium focus:outline-none focus:ring-1 ${
                                  hasConflict
                                    ? 'bg-rose-50 border-rose-300 text-rose-900 focus:ring-rose-500'
                                    : assignedPersId
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950 focus:ring-emerald-500'
                                    : 'bg-slate-50 border-slate-200 text-slate-500 focus:ring-slate-500'
                                }`}
                              >
                                <option value="">-- Personel Seçin --</option>
                                {activePersonnel.map(p => (
                                  <option key={p.id} value={p.id} className={p.isActive ? "" : "text-slate-400"}>
                                    {p.name} {!p.isActive ? '(Pasif)' : ''}
                                  </option>
                                ))}
                              </select>
                            </td>

                            {/* Status Indicators Badging */}
                            <td className="py-3 px-4 text-center">
                              {hasConflict ? (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-red-700 bg-red-100 border border-red-200 px-2 py-0.5 rounded-full select-none animate-pulse">
                                  <AlertTriangle className="w-3 h-3" />
                                  Ardışık Tekrar!
                                </span>
                              ) : assignedPersId ? (
                                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2.5 py-0.5 rounded-full select-none">
                                  <Check className="w-3 h-3" />
                                  Rotasyon Tamam
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[10px] font-medium text-amber-700 bg-amber-50 border border-amber-100 px-2.5 py-0.5 rounded-full select-none">
                                  Eklenmedi
                                </span>
                              )}
                            </td>

                          </tr>
                        );
                      })}

                      {activeRegions.length === 0 && (
                        <tr>
                          <td colSpan={6} className="py-12 text-center text-slate-400 italic">
                            Bu ilçeye ait tanımlı okuma bölgesi bulunmamaktadır. Bölgeler sekmesinden yeni mahalleler tanımlayabilirsiniz.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Print only template inside the workspace */}
                <div className="print-only hidden p-8 bg-white text-slate-900 border border-slate-300 rounded-lg">
                  <div className="text-center pb-6 border-b-2 border-slate-900">
                    <h2 className="text-2xl font-bold uppercase tracking-tight">Doğal Gaz Dağıtım Şefliği</h2>
                    <h3 className="text-lg font-semibold mt-1">{selectedDistrict} İlçesi Sayaç Okuma Görev Dağılımı</h3>
                    <p className="text-sm text-slate-500 font-mono mt-1">Dönem: {MONTH_NAMES[planningMonthIndex]} {planningYear}</p>
                  </div>

                  <table className="w-full text-sm text-left mt-6 border-collapse">
                    <thead>
                      <tr className="border-b-2 border-slate-400 font-bold uppercase text-xs">
                        <th className="py-2">No</th>
                        <th className="py-2">Süreç / Mahalle Bölgesi</th>
                        <th className="py-2 text-right">Hedef Abone</th>
                        <th className="py-2 pl-6">Okuma Sorumlusu</th>
                        <th className="py-2 text-center">İmza / Durum</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      {activeRegions.map((r, i) => {
                        const assignedId = tempAssignments[r.id];
                        const pers = personnel.find(p => p.id === assignedId);
                        return (
                          <tr key={r.id}>
                            <td className="py-3 font-mono">{i + 1}</td>
                            <td className="py-3">
                              <span className="font-bold">{r.neighborhoodName}</span> - {r.regionName}
                            </td>
                            <td className="py-3 text-right font-mono font-semibold">{r.subscribersCount}</td>
                            <td className="py-3 pl-6 font-bold text-slate-800">
                              {pers ? pers.name : 'ATANMADI'}
                            </td>
                            <td className="py-3 text-center border-l border-slate-200">
                              <span className="inline-block w-16 h-4 border border-dashed border-slate-400 rounded-xs"></span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>

                  <div className="mt-12 flex justify-between text-xs pt-8 border-t border-slate-200">
                    <div>
                      <span className="block font-bold">Planlama Şefi Hazırlayan</span>
                      <span className="block mt-8 border-t border-slate-500 w-36">İmza</span>
                    </div>
                    <div>
                      <span className="block font-bold">Doğal Gaz Operasyon Müdürü</span>
                      <span className="block mt-8 border-t border-slate-500 w-36">İmza / Onay</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB: PERSONEL YÖNETİMİ                                    */}
        {/* ========================================================= */}
        {activeTab === 'personnel' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            
            {/* Left Column: Form to insert new staff */}
            <div className="md:col-span-4 bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col gap-4">
              <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <User className="w-4 h-4 text-emerald-500" />
                  Yeni Personel Ekle
                </span>
                <button
                  onClick={() => setShowBulkModal('personnel')}
                  className="text-[10px] text-amber-600 hover:text-amber-700 font-bold border border-amber-200 bg-amber-50 rounded-lg px-2 py-1 flex items-center gap-1 transition-colors"
                >
                  <Upload className="w-3 h-3" /> Toplu Ekle
                </button>
              </h3>

              <form onSubmit={handleAddPersonnel} className="flex flex-col gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-bold block mb-1">Cihaz / Personel Adı Soyadı</label>
                  <input
                    type="text"
                    required
                    value={newPersName}
                    onChange={(e) => setNewPersName(e.target.value)}
                    placeholder="Örn: Serhat Demiröz"
                    className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2.5 font-medium placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 font-bold block mb-1">Grup Görev Bölgesi</label>
                  <input
                    type="text"
                    disabled
                    value={selectedDistrict}
                    className="w-full bg-slate-100 border border-slate-200 text-xs rounded-lg p-2.5 font-medium text-slate-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 border border-emerald-500 shadow-md transform hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Sisteme Kaydet
                </button>
              </form>
            </div>

            {/* Right Column: List of existing staff */}
            <div className="md:col-span-8 bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-slate-500" />
                    {selectedDistrict} Sahada Görevli Aktif Personel Listesi
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Okumaya gidemeyen personelleri &apos;Pasif&apos; durumuna getirerek atama hesaplarından geçici olarak çıkarabilirsiniz.
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-400 font-bold tracking-wider uppercase select-none">
                      <th className="py-3 px-4">Kart No</th>
                      <th className="py-3 px-4">Ad Soyad</th>
                      <th className="py-3 px-4 text-center">Bölgesi</th>
                      <th className="py-3 px-4 text-center">Saha Çalışma Durumu</th>
                      <th className="py-3 px-4 text-right">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {activePersonnel.map((person, index) => (
                      <tr key={person.id} className="hover:bg-slate-50 transition-colors">
                        
                        <td className="py-3.5 px-4 font-mono text-slate-400">
                          PER-{String(index + 1).padStart(3, '0')}
                        </td>

                        <td className="py-3.5 px-4 font-bold text-slate-900 text-sm">
                          {person.name}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md text-[10px] font-bold">
                            {person.district}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <button
                            onClick={() => togglePersonnelStatus(person.id)}
                            className={`px-3 py-1 rounded-full text-[10px] font-bold border transition-colors inline-flex cursor-pointer select-none ${
                              person.isActive
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
                                : 'bg-slate-100 border-slate-200 text-slate-400 hover:bg-slate-200'
                            }`}
                          >
                            {person.isActive ? '✓ Aktif (Okumaya Hazır)' : '✕ Pasif (Ayrıldı / İzinli)'}
                          </button>
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => handleDeletePersonnel(person.id, person.name)}
                            className="bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 p-1.5 rounded-lg transition-colors cursor-pointer"
                            title="Personeli Sil"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>

                      </tr>
                    ))}

                    {activePersonnel.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400 italic">
                          Kayıtlı saha personeli bulunmamaktadır. Soldaki formu kullanarak ekleyin.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB: BÖLGELER VE MAHALLER                                  */}
        {/* ========================================================= */}
        {activeTab === 'regions' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            
            {/* Left Column: Form to insert new region */}
            <div className="md:col-span-4 bg-white rounded-xl shadow-xs border border-slate-200 p-5 flex flex-col gap-4">
              <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Map className="w-4 h-4 text-emerald-500" />
                  Yeni Bölge Kaydet
                </span>
                <button
                  onClick={() => setShowBulkModal('regions')}
                  className="text-[10px] text-amber-600 hover:text-amber-700 font-bold border border-amber-200 bg-amber-50 rounded-lg px-2 py-1 flex items-center gap-1 transition-colors"
                >
                  <Upload className="w-3 h-3" /> Toplu Ekle
                </button>
              </h3>

              <form onSubmit={handleAddRegion} className="flex flex-col gap-3">
                <div>
                  <label className="text-xs text-slate-400 font-bold block mb-1">Mahalle Adı</label>
                  <input
                    type="text"
                    required
                    value={newRegNeighborhood}
                    onChange={(e) => setNewRegNeighborhood(e.target.value)}
                    placeholder="Örn: Şehitlik Mahallesi"
                    className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2.5 font-medium placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 font-bold block mb-1">Bölge No / Kodu</label>
                  <input
                    type="text"
                    required
                    value={newRegName}
                    onChange={(e) => setNewRegName(e.target.value)}
                    placeholder="Örn: Bölge 1"
                    className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2.5 font-medium placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 font-bold block mb-1">Kayıtlı Abone Sayısı</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={newRegSubscribers}
                    onChange={(e) => setNewRegSubscribers(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="Örn: 150"
                    className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2.5 font-medium placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                  <span className="text-[10px] text-slate-400 block mt-1">İş yükü bu abone sayısına göre eşit paylaştırılır.</span>
                </div>

                <div>
                  <label className="text-xs text-slate-400 font-bold block mb-1">İlçe</label>
                  <input
                    type="text"
                    disabled
                    value={selectedDistrict}
                    className="w-full bg-slate-100 border border-slate-200 text-xs rounded-lg p-2.5 font-medium text-slate-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 border border-emerald-500 shadow-md transform hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Bölgeyi Ekle
                </button>
              </form>
            </div>

            {/* Right Column: List of existing regions */}
            <div className="md:col-span-8 bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    <Map className="w-4 h-4 text-slate-500" />
                    {selectedDistrict} Doğal Gaz Dağıtım Bölgeleri
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    İlçe sınırlarındaki aktif sayaç okunan alt şebeke dağıtım bölgelerinin dökümü ve abone sayıları.
                  </p>
                </div>
                <div className="text-xs font-mono font-bold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-lg">
                  Toplam: {activeRegions.reduce((sum, r) => sum + r.subscribersCount, 0).toLocaleString()} Abone
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[10px] text-slate-400 font-bold tracking-wider uppercase select-none">
                      <th className="py-3 px-4">No</th>
                      <th className="py-3 px-4">Mahalle Adı</th>
                      <th className="py-3 px-4">Bölge Kodu</th>
                      <th className="py-3 px-4 text-right">Abone Kapasitesi</th>
                      <th className="py-3 px-4 text-right">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {activeRegions.map((region, index) => (
                      <tr key={region.id} className="hover:bg-slate-50 transition-colors">
                        
                        <td className="py-3 px-4 font-mono text-slate-400">
                          #{String(index + 1).padStart(3, '0')}
                        </td>

                        <td className="py-3 px-4 font-bold text-slate-800 text-sm">
                          {region.neighborhoodName}
                        </td>

                        <td className="py-3 px-4">
                          <span className="font-semibold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2.5 py-0.5 rounded-full">
                            {region.regionName}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-700 text-sm">
                          {region.subscribersCount.toLocaleString()} Abone
                        </td>

                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => handleDeleteRegion(region.id, `${region.neighborhoodName} ${region.regionName}`)}
                            className="bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 p-1.5 rounded-lg transition-colors cursor-pointer"
                            title="Bölgeyi Sil"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>

                      </tr>
                    ))}

                    {activeRegions.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400 italic">
                          Kayıtlı bölge bulunmamaktadır. Soldaki formu veya toplu ekleme panelini kullanın.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB: GEÇMİŞ DÖNEM ARŞİVİ                                  */}
        {/* ========================================================= */}
        {activeTab === 'history' && (
          <>
            <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden">
            <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                <Calendar className="w-5 h-5 text-emerald-500" />
                Arşivlenmiş Geçmiş Dönem Atama Kayıtları
              </h2>
              <p className="text-xs text-slate-500">
                Seçili ilçede ({selectedDistrict}) daha önce kaydedilmiş atama planlarının geçmiş listesidir. Bu kayıtlar rotasyon kontrolüne otomatik temel oluşturur.
              </p>
            </div>

            <div className="divide-y divide-slate-100">
              {records.filter(r => r.district === selectedDistrict).map((record) => (
                <div key={record.id} className="p-5 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between hover:bg-slate-50/50 transition-colors">
                  
                  {/* Left Side Info */}
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-extrabold text-slate-900">{record.monthLabel}</span>
                      <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-md">
                        {record.district} Planı
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 font-mono">
                      Kayıt Kimliği: {record.id} • Oluşturulma: {new Date(record.createdAt).toLocaleString('tr-TR')}
                    </p>
                    <p className="text-xs text-slate-600 mt-2">
                      Toplam <strong className="text-slate-800">{record.assignments.length} bölge</strong> dağıtımı bu dönem başarıyla gerçekleştirildi.
                    </p>
                  </div>

                  {/* Actions Right Side */}
                  <div className="flex items-center gap-2 self-end md:self-auto">
                    
                    {/* View/Restore Plan on Planning Screen */}
                    <button
                      onClick={() => {
                        // Restore assignments mapping for preview
                        const restored: Record<string, string> = {};
                        for (const a of record.assignments) {
                          restored[a.regionId] = a.personnelId;
                        }
                        
                        // Parse Year and Month from ID to set pickers
                        const parts = record.id.split('-');
                        if (parts.length >= 2) {
                          setPlanningYear(Number(parts[0]));
                          // Month is 1-indexed in ID, 0-indexed in index state
                          setPlanningMonthIndex(Number(parts[1]) - 1);
                        }

                        setTempAssignments(restored);
                        setActiveTab('planning');
                        showNotification(`"${record.monthLabel}" atama planı masaya yüklendi!`, 'success');
                      }}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                      Masaya Yükle
                    </button>

                    {/* Delete Plan */}
                    <button
                      onClick={() => handleDeleteRecord(record.id, record.monthLabel)}
                      className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Arşivden Sil
                    </button>

                  </div>

                </div>
              ))}

              {records.filter(r => r.district === selectedDistrict).length === 0 && (
                <div className="py-20 text-center text-slate-400 italic">
                  Henüz seçili ilçeye ait bir arşiv kaydı bulunmamaktadır. Bölge atama masasından plan hazırlayıp kaydedebilirsiniz.
                </div>
              )}
            </div>
          </div>

          {/* Saha Verileri Yedekleme ve Geri Yükleme */}
          <div className="mt-6 bg-white rounded-xl shadow-xs border border-slate-200 p-5">
            <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
              <Download className="w-4 h-4 text-emerald-500" />
              Saha Verileri Yedekleme ve Geri Yükleme
            </h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Tarayıcı çerezlerinizin silinmesi durumunda planlama verilerinizin kaybolmaması için tüm sistemi (tanımladığınız personelleri, mahalleleri ve kayıt geçmişini) yedek dosyası (.json) olarak bilgisayarınıza indirebilir, daha sonra geri yükleyebilirsiniz.
            </p>
            
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <button
                onClick={handleExportBackup}
                className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-400 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Saha Verilerini Yedek Dosyası İndir (Dışa Aktar)
              </button>

              <label className="px-4 py-2.5 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 text-slate-700 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer relative">
                <Upload className="w-4 h-4 text-emerald-500" />
                Yedekten Geri Yükle (Dosya Seç)
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportBackup}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </label>
            </div>
          </div>
        </>
      )}

      </main>

      {/* --- EXTRA EXPLAINER FOOTER ACCENT --- */}
      <footer className="bg-slate-100 border-t border-slate-200 py-6 mt-12 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-400 flex flex-col items-center gap-2">
          <div>Doğal Gaz Dağıtım Şefliği Sayaç Okuma & Rotasyon Planlayıcı Uygulaması</div>
          <div className="font-mono text-[10px]">
            © 2026 GazDağıtım A.Ş. • Polatlı Şefliği (8 Personel) • Beypazarı Şefliği (4 Personel)
          </div>
        </div>
      </footer>

      {/* ========================================================= */}
      {/* BULK UPLOAD MODALS                                        */}
      {/* ========================================================= */}
      {showBulkModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 no-print">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden flex flex-col">
            
            <div className="p-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Upload className="w-4 h-4 text-amber-500" />
                {showBulkModal === 'personnel' ? 'Toplu Personel Ekle' : 'Toplu Bölge & Mahalle Ekle'}
              </h3>
              <button
                onClick={() => {
                  setShowBulkModal(null);
                  setBulkPersonnelText('');
                  setBulkRegionsText('');
                }}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 flex flex-col gap-4">
              
              <div className="text-xs text-slate-500 leading-relaxed bg-slate-100 p-3 rounded-lg border border-slate-200">
                {showBulkModal === 'personnel' ? (
                  <>
                    <strong className="text-slate-700">Format Talimatı:</strong> Her satıra bir personel gelecek şekilde kopyalayıp yapıştırabilirsiniz. Boş satırlar elenecektir.
                    <pre className="mt-2 text-[10px] bg-white p-2 rounded-md border text-slate-600 font-mono">
                      Ali Yılmaz{"\n"}Hasan Demir{"\n"}Zeynep Kaya
                    </pre>
                  </>
                ) : (
                  <>
                    <strong className="text-slate-700">Format Talimatı:</strong> Excel tablonuzdan 3 sütunu kapsayacak şekilde (Mahalle Adı, Bölge Adı, Abone Sayısı) kopyalayıp yapıştırabilirsiniz. Tablo sekmesi (Tab) ayracı otomatik algılanır.
                    <pre className="mt-2 text-[10px] bg-white p-2 rounded-md border text-slate-600 font-mono">
                      Şehitlik Mahallesi [Tab] Bölge 1 [Tab] 150{"\n"}
                      Şehitlik Mahallesi [Tab] Bölge 2 [Tab] 185
                    </pre>
                  </>
                )}
              </div>

              <div>
                <label className="text-xs text-slate-400 font-bold block mb-1">
                  Verileri Buraya Yapıştırın
                </label>
                <textarea
                  rows={8}
                  value={showBulkModal === 'personnel' ? bulkPersonnelText : bulkRegionsText}
                  onChange={(e) => {
                    if (showBulkModal === 'personnel') {
                      setBulkPersonnelText(e.target.value);
                    } else {
                      setBulkRegionsText(e.target.value);
                    }
                  }}
                  placeholder={
                    showBulkModal === 'personnel'
                      ? "Örn:\nCan Özdemir\nKübra Şen\nHüseyin Öztürk"
                      : "Örn:\nŞehitlik Mahallesi\tBölge 1\t150\nŞehitlik Mahallesi\tBölge 2\t185"
                  }
                  className="w-full bg-slate-50 border border-slate-200 text-xs rounded-lg p-2.5 font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                ></textarea>
              </div>

            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-150 flex items-center justify-end gap-2">
              <button
                onClick={() => {
                  setShowBulkModal(null);
                  setBulkPersonnelText('');
                  setBulkRegionsText('');
                }}
                className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-500"
              >
                Vazgeç
              </button>
              <button
                onClick={showBulkModal === 'personnel' ? handleImportPersonnelBulk : handleImportRegionsBulk}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-xs"
              >
                Sisteme İthal Et
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
