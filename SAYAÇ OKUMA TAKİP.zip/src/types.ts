export interface Personnel {
  id: string;
  name: string;
  district: 'Polatlı' | 'Beypazarı';
  isActive: boolean;
}

export interface Region {
  id: string;
  neighborhoodName: string; // e.g. "Şehitlik"
  regionName: string; // e.g. "Bölge 1"
  subscribersCount: number;
  district: 'Polatlı' | 'Beypazarı';
}

export interface Assignment {
  regionId: string;
  personnelId: string;
}

export interface MonthRecord {
  id: string; // Format: "YYYY-MM"
  monthLabel: string; // e.g., "Haziran 2026"
  district: 'Polatlı' | 'Beypazarı';
  assignments: Assignment[];
  createdAt: string;
}
