package com.dogalgaz.okuma.planlayici;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
